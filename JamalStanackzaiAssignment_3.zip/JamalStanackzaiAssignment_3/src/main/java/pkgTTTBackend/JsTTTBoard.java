package pkgTTTBackend;

import java.util.Scanner;
import static pkgTTTBackend.JsIOManager.*;

public class JsTTTBoard {
    private final int ROW = 3, COL = 3;
    private final char player_char = 'P';
    private final char machine_char = 'C';
    private final char default_char = '-';

    private int totalValidentries = 0;
    private char winner_char = '-';

    private char[][] ttt_board = new char[3][3];

    // Constructor
    public JsTTTBoard() {
        for (int y = 0; y < ROW; y++) {
            for (int x = 0; x < COL; x++) {
                ttt_board[y][x] = default_char;
            }
        }
    }

    public char[][] getBoard() {
        return ttt_board;
    }

    public void testPlay() {
        // Fill in board diagonally, if not valid then fill in row
        for (int a = 0; a < 2; a++) {
            for (int y = 0; y < ROW; y++) {
                for (int x = 0; x < COL; x++) {
                    if (x == y) {
                        boolean result = updateBoard(x, y);
                        if (result) {
                            printBoard(this);
                        }
                        else {
                            for (int i = 0; i < COL; i++) {
                                if (updateBoard(i, y)) {
                                    printBoard(this);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public void clearBoard() {
        for (int y = 0; y < ROW; y++) {
            for (int x = 0; x < COL; x++) {
                ttt_board[y][x] = default_char;
            }
        }
        totalValidentries = 0;
        winner_char = '-';
    }

    private boolean updateBoard(int x, int y) {
        if (totalValidentries >= ROW * COL) {
            return false;
        }

        if (x >= 0 && x < COL && y >= 0 && y < ROW) {
            if (ttt_board[y][x] == default_char) {
                ttt_board[y][x] = player_char;
                totalValidentries += 1;
                return true;
            }
        }
        return false;
    }

    public void play() {
        // use player_char and machine_car instead of X's and O's
        // Read user input and play game

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Enter your move: Row and column (separated by a space), or press 'q' to quit: ");

            if (scanner.hasNext("q")) {
                System.out.println("Game exited. Thanks for playing!");
                break;
            }

            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter two numbers separated by a space.");
                scanner.nextLine();
                continue;
            }
            int y = scanner.nextInt();

            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter two numbers separated by a space.");
                scanner.nextLine();
                continue;
            }
            int x = scanner.nextInt();
            scanner.nextLine();

            if (x < 0 || x >= COL || y < 0 || y >= ROW) {
                System.out.println("Invalid move. Try again.");
                continue;
            }

            if (ttt_board[y][x] != default_char) {
                System.out.println("That cell is already marked. Try again.");
                continue;
            }

            updateBoard(x, y);
            printBoard(this);

            if (totalValidentries == ROW*COL) {
                System.out.println("All positions have been filled. Game over!");
                break;
            }
        }
        scanner.close();
    }

}