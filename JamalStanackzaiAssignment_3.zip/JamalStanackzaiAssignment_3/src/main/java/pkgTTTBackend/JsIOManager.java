package pkgTTTBackend;

import java.util.Scanner;

public class JsIOManager {
    private JsIOManager() {
    }

    static private Scanner myScanner = new Scanner(System.in);

    static public void cellNotFreeMessage(int x, int y) {
        System.out.println("Cell (" + x + "," + y + ") is not free. Please choose another one.");
    }

    static public void rowColPrompt() {
        System.out.print("Enter the row and column (0-2): ");
    }

    static public boolean readQuitInput() {
        String input = myScanner.nextLine();
        return input.equalsIgnoreCase("quit");
    }

    static public void boardCompleteMessage() {
        System.out.println("The board is complete. No more moves can be made.");
    }

    static public int[] readIntegerInput(int x) {
        int[] result = new int[2];
        rowColPrompt();
        String input = myScanner.nextLine();
        String[] parts = input.split(",");
        if (parts.length != 2) {
            System.out.println("Invalid input. Please enter two numbers separated by a comma.");
            return null;
        }
        try {
            result[0] = Integer.parseInt(parts[0]);
        }
        catch (NumberFormatException e) {
            System.out.println("Invalid row number. Please enter a number between 0 and 2.");
            return null;
        }
        try {
            result[1] = Integer.parseInt(parts[1]);
            if (result[1] < 0 || result[1] > 2) {
                System.out.println("Invalid column number. Please enter a number between 0 and 2.");
                return null;
                
            }
            return result;

        } catch (NumberFormatException e) {
            System.out.println("Invalid column number. Please enter a number between 0 and 2.");
            return null;
            
        }
    }

    static public void invalidEntryMessage() {
        System.out.println("Invalid entry. Please try again.");
    }

    static public void printBoard(JsTTTBoard board) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(board.getBoard()[i][j]);
                if (j < 2) {
                    System.out.print(" ");
                }
            }
            System.out.println();
        }
        System.out.println();
    }

    static public void initPrompt() {
        System.out.println("Welcome to Tic Tac Toe! Please enter your move in the format 'row column'.");
    }

    static public void quitGameMessage() {
        System.out.println("Thank you for playing Tic Tac Toe. Goodbye!");
    }

}